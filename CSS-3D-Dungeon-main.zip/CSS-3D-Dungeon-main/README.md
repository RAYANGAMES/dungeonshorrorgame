<img src="./github extras/github poster.jpg">

# 3D environment built with css transformations

### Preview

<img width="49%" src="./github extras/preview 1.gif" alt="preview 1"> <img width="49%" src="./github extras/preview 2.gif" alt="preview 2">

### About

*  :package: 3D environment build on native html/css
*  :video_game: one full level with interactive items and puzzles
*  :ant: bugs and fps drops are also available
  
### Tech stack

<img src="./github extras/tech stack.jpg" alt="tech stack list">

Have Fun: <a href="https://mero-plaform.github.io/CSS-3D-Dungeon"> pages link </a>
